"""Generator internals."""
