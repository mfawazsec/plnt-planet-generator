"""Generator internals."""
